import type React from "react"
import { RegisterForm } from "../../components/auth/RegisterForm"

export const RegisterPage: React.FC = () => {
  return <RegisterForm />
}

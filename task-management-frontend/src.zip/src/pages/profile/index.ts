export { ProfilePage } from "./ProfilePage"
